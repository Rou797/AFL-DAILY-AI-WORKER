from google_auth_oauthlib.flow import InstalledAppFlow
from pathlib import Path
SCOPES=["https://www.googleapis.com/auth/youtube.upload"]
flow=InstalledAppFlow.from_client_secrets_file("client_secret.json",SCOPES)
creds=flow.run_local_server(port=0,access_type="offline",prompt="consent")
Path("youtube_token.json").write_text(creds.to_json(),encoding="utf-8")
print("Created youtube_token.json. Keep it private and store it as the YOUTUBE_TOKEN_JSON GitHub secret.")
