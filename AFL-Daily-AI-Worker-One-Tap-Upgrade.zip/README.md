# AFL Daily AI Worker

Automates AFL Daily with GitHub Actions: read AFL news, choose a topic, write a script, generate narration/video, and upload through YouTube API.

## One-time YouTube authorization
YouTube Studio does not have a general external-AI connect button. The official API uses Google OAuth. `worker/youtube_auth_helper.py` performs the one-time browser authorization and creates `youtube_token.json`; store its contents as the GitHub Actions secret `YOUTUBE_TOKEN_JSON`.

Never paste passwords, API keys, OAuth tokens, or client secrets into ChatGPT or commit them to GitHub.

Note: Google can restrict uploads from unverified API projects to private visibility until the project passes its required audit.
