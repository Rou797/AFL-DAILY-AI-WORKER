# AFL Daily AI Worker

A GitHub Actions worker for AFL Daily.

## What it is designed to do
1. Run automatically on a schedule.
2. Pull current AFL stories from RSS feeds.
3. Ask an AI model to choose a topic, research it from the supplied sources, fact-check it, and write a short-form script.
4. Generate narration with Edge TTS.
5. Build a vertical MP4 with captions using FFmpeg.
6. Generate YouTube metadata.
7. Upload to YouTube when YouTube OAuth credentials are configured.
8. Keep a small state file so the same story is not repeatedly selected.

## Important
This repository contains NO passwords, API keys, OAuth tokens, or client secrets.

The worker can be built now, but automatic YouTube publishing necessarily requires you to authorize your own YouTube/Google account at some point. I have intentionally not included or requested any credentials.

## Current architecture
GitHub Actions -> RSS news -> AI -> script -> Edge TTS -> FFmpeg -> YouTube

The workflow is scheduled for once per day and can also be run manually.

## Secrets the workflow expects later
- `AI_API_KEY`
- `YOUTUBE_CLIENT_SECRET_JSON`
- `YOUTUBE_TOKEN_JSON`

The code is written so the AI endpoint/model can be changed through environment variables.
