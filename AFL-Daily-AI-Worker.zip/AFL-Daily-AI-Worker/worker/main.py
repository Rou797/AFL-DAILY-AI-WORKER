import os, json, re, subprocess, textwrap, hashlib
from pathlib import Path
import feedparser
import requests
import edge_tts

ROOT = Path(__file__).resolve().parent
STATE = ROOT / "state.json"
OUT = ROOT / "output"
OUT.mkdir(exist_ok=True)

FEEDS = [
    "https://www.afl.com.au/news.rss",
    "https://www.espn.com.au/espn/rss/afl/news",
]

def load_state():
    try:
        return json.loads(STATE.read_text())
    except Exception:
        return {"used_urls": []}

def save_state(s):
    STATE.write_text(json.dumps(s, indent=2))

def fetch_stories():
    stories = []
    for url in FEEDS:
        try:
            feed = feedparser.parse(url)
            for e in feed.entries[:15]:
                link = e.get("link", "")
                title = e.get("title", "").strip()
                summary = re.sub(r"\s+", " ", re.sub("<[^>]+>", " ", e.get("summary", ""))).strip()
                if title and link:
                    stories.append({"title": title, "summary": summary[:1200], "url": link})
        except Exception as exc:
            print("Feed error:", url, exc)
    return stories

def call_ai(prompt):
    key = os.environ.get("AI_API_KEY")
    if not key:
        raise RuntimeError("AI_API_KEY is not configured yet.")
    base = os.environ.get("AI_BASE_URL", "https://api.groq.com/openai/v1")
    model = os.environ.get("AI_MODEL", "llama-3.3-70b-versatile")
    r = requests.post(
        base.rstrip("/") + "/chat/completions",
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        json={"model": model, "temperature": 0.4, "messages": [
            {"role": "system", "content": "You are the editorial AI for AFL Daily. Never invent facts. If a claim is not supported by the supplied sources, say it is unconfirmed."},
            {"role": "user", "content": prompt},
        ]},
        timeout=90,
    )
    r.raise_for_status()
    return r.json()["choices"][0]["message"]["content"]

def choose_story(stories, used):
    fresh = [s for s in stories if s["url"] not in used]
    if not fresh:
        fresh = stories
    if not fresh:
        raise RuntimeError("No AFL stories were found.")
    source_text = "\n\n".join(
        f"STORY {i+1}\nTITLE: {s['title']}\nSUMMARY: {s['summary']}\nURL: {s['url']}"
        for i, s in enumerate(fresh[:25])
    )
    prompt = f"""Choose the single strongest current AFL Daily short-video topic from these source items.

Return JSON only:
{{"index": 1, "reason": "brief reason"}}

Do not choose a story merely because the headline sounds dramatic. Prefer current, specific, verifiable AFL news.

{source_text}"""
    raw = call_ai(prompt)
    m = re.search(r"\{.*\}", raw, re.S)
    data = json.loads(m.group(0))
    idx = int(data["index"]) - 1
    return fresh[max(0, min(idx, len(fresh)-1))]

def create_package(story):
    prompt = f"""Create an AFL Daily YouTube Short based ONLY on the source below.

SOURCE TITLE: {story['title']}
SOURCE SUMMARY: {story['summary']}
SOURCE URL: {story['url']}

Return JSON only with:
title: a punchy accurate YouTube title under 90 characters
description: 2-4 sentences plus source URL
hashtags: 5-8 relevant hashtags
script: 100-150 spoken words

Rules:
- Do not invent scores, injuries, trades, quotes, dates, or player statements.
- Distinguish confirmed news from speculation.
- No fake quotes.
- Make the opening sentence immediately interesting.
- The script must sound natural when spoken aloud."""
    raw = call_ai(prompt)
    m = re.search(r"\{.*\}", raw, re.S)
    return json.loads(m.group(0))

async def make_voice(text, path):
    communicate = edge_tts.Communicate(text, "en-AU-WilliamNeural")
    await communicate.save(str(path))

def make_video(script, audio_path, output_path):
    # Simple branded vertical video: dark background + animated text captions.
    # This deliberately avoids scraping copyrighted match footage.
    caption = re.sub(r"[%:,\n]", " ", script)
    # Use ffmpeg's drawtext with a generated text file for reliability.
    textfile = OUT / "caption.txt"
    textfile.write_text(script, encoding="utf-8")
    cmd = [
        "ffmpeg", "-y",
        "-f", "lavfi", "-i", "color=c=black:s=1080x1920:r=30",
        "-i", str(audio_path),
        "-vf",
        "drawtext=fontfile=/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf:"
        "textfile='" + str(textfile).replace("'", r"'\''") + "':"
        "fontcolor=white:fontsize=54:line_spacing=12:"
        "x=(w-text_w)/2:y=(h-text_h)/2:"
        "box=1:boxcolor=black@0.55:boxborderw=35",
        "-c:v", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "128k", "-shortest",
        str(output_path),
    ]
    subprocess.run(cmd, check=True)

def youtube_upload(video_path, package):
    client_json = os.environ.get("YOUTUBE_CLIENT_SECRET_JSON")
    token_json = os.environ.get("YOUTUBE_TOKEN_JSON")
    if not client_json or not token_json:
        print("YouTube credentials are not configured. Video was generated but not uploaded.")
        return False

    from google.oauth2.credentials import Credentials
    from googleapiclient.discovery import build
    from googleapiclient.http import MediaFileUpload

    creds = Credentials.from_authorized_user_info(
        json.loads(token_json),
        scopes=["https://www.googleapis.com/auth/youtube.upload"]
    )
    youtube = build("youtube", "v3", credentials=creds)
    body = {
        "snippet": {
            "title": package["title"],
            "description": package["description"],
            "tags": [x.lstrip("#") for x in package["hashtags"]],
            "categoryId": "17",
        },
        "status": {
            "privacyStatus": "private"
        }
    }
    request = youtube.videos().insert(
        part="snippet,status",
        body=body,
        media_body=MediaFileUpload(str(video_path), mimetype="video/mp4", resumable=True)
    )
    response = request.execute()
    print("Uploaded video:", response.get("id"))
    return True

def main():
    state = load_state()
    stories = fetch_stories()
    story = choose_story(stories, set(state.get("used_urls", [])))
    package = create_package(story)

    digest = hashlib.sha1(story["url"].encode()).hexdigest()[:10]
    audio = OUT / f"voice-{digest}.mp3"
    video = OUT / f"afl-daily-{digest}.mp4"

    import asyncio
    asyncio.run(make_voice(package["script"], audio))
    make_video(package["script"], audio, video)

    (OUT / "latest.json").write_text(json.dumps({
        "source": story,
        "package": package,
        "video": str(video)
    }, indent=2), encoding="utf-8")

    youtube_upload(video, package)

    used = state.setdefault("used_urls", [])
    if story["url"] not in used:
        used.append(story["url"])
    state["used_urls"] = used[-100:]
    save_state(state)

if __name__ == "__main__":
    main()
